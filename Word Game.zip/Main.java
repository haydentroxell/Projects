//Hayden Troxell
import java.util.*;
import java.io.*;
class Main {

  //Checks if word is correct
  public static boolean checkContains(String enteredWord, String checkWord){
    boolean letterCheck = true;
    char[] enteredWordCA = enteredWord.toCharArray();
    char[] checkWordCA = checkWord.toCharArray();
    //Nested loop to run through words
    for (int i = 0; i < enteredWord.length() - 1; i++) {
        for (int j = i; j < checkWord.length(); j++) {
          //checks letters entered are equal to checked letters
            if (checkWordCA[j] == enteredWordCA[i]) {
              letterCheck = true;
              break;
            }else{
              letterCheck = false;
            }
        }if(!letterCheck){
          return false;
        }
      
    }
    return true;
  }
  
  //Shuffles chosen word
  public static String shuffleWord(String word){
    ArrayList<Character> shuffled = new ArrayList<Character>();
    char[] temp = word.toCharArray();
    for(int i = 0; i < word.length(); i++){
      shuffled.add(temp[i]);
    }
    Collections.shuffle(shuffled);
    String returnWord = "";
    for(int i = 0; i < shuffled.size(); i++){
       returnWord += shuffled.get(i);
      returnWord += " ";
      
    }
    return returnWord;
  }
  
  //Makes sure all characters are unique in chosen word
  public static boolean checkUnique(String word){
    char[] wordCA = word.toCharArray();
    boolean unique = true;
    
    for (int i = 0; i < word.length() - 1; i++) {
        for (int j = i + 1; j < word.length(); j++) {
            if (wordCA[i] == wordCA[j]) {
                return false;
            }
        }
    }
    return unique;
  }
  
  //Gets words into Array list
  public static ArrayList<String> getWords(String filename) throws Exception{
    BufferedReader bufReader = new BufferedReader(new       
    FileReader(filename)); 
    ArrayList<String> words = new ArrayList<>(); 
    String line = bufReader.readLine();
  while (line != null) { 
    words.add(line); 
    line = bufReader.readLine(); 
  }
    return words;

  }
  
  //Chooses word from list to use for game
  public static String chooseWord(ArrayList<String> words){
    Collections.shuffle(words);
    String returnString = "";
    for(int i = 0; i < words.size(); i++ ){
      if(words.get(i).length()==7){
        if(checkUnique(words.get(i))){
          returnString = words.get(i);
      }
    }
    }
    return returnString;
  }

  //Main Method
  public static void main(String[] args) throws Exception {
   Scanner ab = new Scanner(System.in);
    //Set up methods
    ArrayList<String> words = getWords("words.txt");
    String gameWord = chooseWord(words);
    String shuffledWord = shuffleWord(gameWord);
    
    System.out.println(shuffledWord);
    String userInput = "";
    int score = 0;
    ArrayList<String> wordsEntered = new ArrayList<String>();
  
    while(!userInput.equals("bye")){
      System.out.println("Score: " + score);
      userInput = ab.nextLine();
      //Shuffles word if "mix" is inputed
      if(userInput.equals("mix")){
        System.out.println(shuffleWord(gameWord));
      //Shows list of correct words already inputed 
      }else if(userInput.equals("ls")){
        for(int i = 0; i < wordsEntered.size(); i++){
          System.out.println(wordsEntered.get(i));
        }
      }else{
        if(userInput.length() >= 4 && checkContains(userInput, gameWord) && words.contains(userInput)){
            //Adds one to score total if length of characters is 4
            if(userInput.length() == 4){
            score++;
            }
            //Adds number of charaters in the word to the score
            else{
            score += userInput.length();
            }
          wordsEntered.add(userInput);
        }
      }
    }
    
  }
}