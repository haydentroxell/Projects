public class TruckBegin extends Event {
  
 public TruckBegin(int ID, double time){
    super(ID, time);
  }
  
}