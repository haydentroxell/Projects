public class TrainNoBlock extends Event {

  public TrainNoBlock(int ID, double endTime) {
    super(ID, endTime);
  }
}