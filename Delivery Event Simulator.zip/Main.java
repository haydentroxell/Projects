//Hayden Troxell
import java.util.*;
import java.io.*;
class Main {
  public static void main(String[] args) {
    
    //Overall Set Up
    double simClock = 0;
    PriorityQueue<Event> events = new PriorityQueue<>();
    int TotalNumOfPackages = 1500;
    double PERCENT_BY_DRONE = 0.25;
    boolean isBlocking = false;
    
    //Line to hold trucks
    Deque<TruckCrosses>truckStack = new ArrayDeque<>();
    Queue<TruckCrosses>truckLine = new LinkedList<>();
    
    //Drone Set Up
    int numOfDrones = (int) (TotalNumOfPackages * PERCENT_BY_DRONE);
    double TimeForDrones = ((numOfDrones * 3)-3)+60;

    //Truck Set Up
    int numOfTrucks = TotalNumOfPackages - numOfDrones;
    //int numOfTrucks = 30;
    if(numOfTrucks % 10 != 0){
      numOfTrucks = numOfTrucks + 1;
    }

    //Creating TruckEvents
    for(int i = 0; i < (numOfTrucks/10) + 1; i++){
      events.offer(new TruckBegin(i,i * 15));
    }
    
    //Train Schedule Set Up
    String filename = "train schedule.txt";
    try{
      Scanner fileIn = new Scanner(new File(filename));
      int trainID = 0;
      while(fileIn.hasNextLine()){
        double trainStartTime = fileIn.nextInt();
        double trainDuration = fileIn.nextInt();
        double stopBlocking = trainStartTime + trainDuration;

        TrainBlock TE = new TrainBlock(trainID, trainStartTime, stopBlocking, trainDuration);
        events.offer(TE);
        trainID++;
      }
    }catch(FileNotFoundException e){
      System.out.println("ERROR: No train schedule found");
    }

    //PRINTS TOP STATS
    System.out.println("With " + PERCENT_BY_DRONE * 100 + "% drones and " + TotalNumOfPackages + " packages," );
    System.out.println("There will be:");
    System.out.println("- " + numOfDrones + " drones");
    System.out.println("- " + numOfTrucks + " trucks");
    System.out.println();

    
    
    //Loop to iterate through Events
    double trainEnds = 0.0;
    while(!events.isEmpty()) {
      Event e = events.poll();
      simClock = e.getTime();
      if(e instanceof TruckBegin) {
        System.out.println(e.getTime() + ": TRUCK #" + e.getID() + " begins journey");
        events.offer(new TruckAtCrossing(e.getID(), e.getTime()+100.0));
      } else if(e instanceof TrainBlock){
        TrainBlock tb = (TrainBlock) e;
        trainEnds = tb.getEndTime();
        isBlocking = true;
        System.out.println(tb.getTime() + ": TRAIN arrives at crossing");
        events.offer(new TrainNoBlock(tb.getID(), tb.getEndTime()));
      }else if(e instanceof TruckAtCrossing) {
        if(isBlocking == false) {
          if(truckLine.isEmpty()){
            System.out.println(e.getTime() + ": TRUCK #" + e.getID() + " approaches crossing");
            events.offer(new TruckCrosses(e.getID(), e.getTime()));
          }else{
            System.out.println(e.getTime() + ": TRUCK #" + e.getID() + " approaches crossing");
            events.offer(new TruckCrosses(e.getID(), truckStack.peek().getTime()+1.0));
            truckLine.poll();
          }   
        }else{
          if(truckLine.isEmpty()){
            events.offer(new TruckCrosses(e.getID(), trainEnds + 1.0));
            truckLine.offer(new TruckCrosses(e.getID(), trainEnds + 1.0));
            truckStack.push(new TruckCrosses(e.getID(), trainEnds + 1.0));
            System.out.println(e.getTime() + ": TRUCK #" + e.getID() + " waits at crossing");
          }else{
            events.offer(new TruckCrosses(e.getID(), truckStack.peek().getTime()+1.0));
            truckLine.offer(new TruckCrosses(e.getID(), truckStack.peek().getTime()+1.0));
            truckStack.push(new TruckCrosses(e.getID(), truckStack.peek().getTime()+1.0));

            truckLine.poll();
            System.out.println(e.getTime() + ": TRUCK #" + e.getID() + " waits at crossing");
            }
          
       }
      }else if(e instanceof TrainNoBlock) {
        isBlocking = false;
        System.out.println(e.getTime() + ": TRAIN leaves crossing");
      }else if(e instanceof TruckCrosses) {
        System.out.println(e.getTime() + ": TRUCK #" + e.getID() + " crosses crossing");
        events.offer(new TruckEnd(e.getID(), simClock + 900));
      } else if(e instanceof TruckEnd) {
        System.out.println(e.getTime() + ": TRUCK #" + e.getID() + " completes journey");
      } 
    }
    //Spaces for organization
    System.out.println();
    System.out.println();

    System.out.println("STATS");
    System.out.println("-----");

    System.out.println("");

    System.out.println("DRONE TRIP TIME: 60.0 minutes");
    System.out.println("DRONE TOTAL TIME: " + TimeForDrones + " minutes");
    
  }
}
