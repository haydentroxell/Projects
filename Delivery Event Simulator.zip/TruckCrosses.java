public class TruckCrosses extends Event {
  
  public TruckCrosses(int ID, double time) {
    super(ID, time);
  }
}