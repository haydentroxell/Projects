public class TruckEnd extends Event {

  public TruckEnd(int ID, double time) {
    super(ID, time);
  }
}