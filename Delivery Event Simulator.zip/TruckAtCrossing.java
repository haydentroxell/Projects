public class TruckAtCrossing extends Event {

  public TruckAtCrossing(int ID, double ArriveTime) {
    super(ID, ArriveTime);
  }
}