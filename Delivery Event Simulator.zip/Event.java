//Hayden Troxell
public class Event implements Comparable<Event>{

  private double time = 0;
  private int ID = 0;
  public Event(int ID, double time){
    this.time = time;
    this.ID = ID;
  }
  
  public double getTime() {
    return time;
  }
  
  public int getID(){
    return ID;
  }
  //Compare to Method
  public int compareTo(Event other){
    if(this.time > other.time){
      return 1;
    }else if(this.time < other.time){
      return -1;
    }else{
      return 0;
    }
  }
  
}
