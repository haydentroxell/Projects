public class TrainBlock extends Event {

  private double endTime;
  private double duration;

  public TrainBlock(int ID, double startTime, double endTime, double duration) {
    super(ID, startTime);
    this.endTime = endTime;
    this.duration = duration;
  }

  public double getEndTime() {
    return endTime;
  }

  public double getDuration() {
    return duration;
  }

  public String toString() {
    return "Train ID " + getID() + "end time " + endTime;
  }
}