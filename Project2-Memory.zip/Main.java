//Hayden Troxell
import javax.swing.*;
import java.awt.*;
import java.util.*;

public class Main {

  //Creating arrayList for ints
  ArrayList <Integer> values = new ArrayList<Integer>();
  //Creating arrayList for buttons
  ArrayList <JButton> buttons = new ArrayList<JButton>();

  //Booleans to check size
  boolean numSize = true;
  boolean buttonSize = true;
  
  //Image of back of card
  ImageIcon back = new ImageIcon("Magic Card Back.png.jpg");

  //Image of card "First"
  ImageIcon one = new ImageIcon("First Card.png");

  //Image of card "Second"
  ImageIcon two = new ImageIcon("Second Card.png");

  //Image of card "Third"
  ImageIcon three = new ImageIcon("Third Card.png");

  //Image of card "Fourth"
  ImageIcon four = new ImageIcon("Fourth Card.png");
  
  //METHODS:
  
  //Method to store values into arrayList
  public void storeNums (int num) {
    if(values.size() < 2){
    values.add(num);
    }else{
      numSize = false;
    }
  }

  //Method to store buttons into arrayList
  public void storeButtons (JButton b) {
    if(buttons.size() < 2){
      buttons.add(b);
    }else{
      buttonSize = false;
    }
  }

  //Method to check if values match
  public void check() {
    if(buttons.size() == 2 && buttons.get(0) != buttons.get(1) && values.size() == 2 && values.get(0) == values.get(1) ){
      matched();
      }else if(values.size() == 2 && buttons.size() == 2 && values.get(0) != values.get(1) || buttons.get(0) == buttons.get(1)){
      revertImage();
      values.clear();
      buttons.clear();
      }else if(values.size() > 2 || buttons.size() > 2) {
      values.clear();
      buttons.clear();
      }
    
    }

  //Method called when buttons match
  public void matched() {
    for (JButton b : buttons) {
      b.setVisible(false);
    }
    updateCheck(2);
    values.clear();
    buttons.clear();
  }
 
  //Method that changes image
  public void changeImage (JButton b, ImageIcon a) {
    if(numSize == true && buttonSize == true){
      b.setIcon(resize(a));
    }
  }

  //Method that reverts the image to back of card
  public void revertImage() {
    for (JButton b : buttons) {
       b.setIcon(resize(back));
    }
    values.clear();
    buttons.clear();
  }

  //Method to resize image
  public ImageIcon resize(ImageIcon a) {
    Image i = a.getImage();
    Image modA = i.getScaledInstance(100, 250, java.awt.Image.SCALE_SMOOTH);
    a = new ImageIcon(modA);
    return a;
  }

  //Counter used to show cards left
  int counter = 8;
  //Label for counter
  JLabel counting = new JLabel("CARDS LEFT: 8 "); 
  
  //Method to update counter
  public void updateCheck(int a) {
    counter = counter - a;
    counting.setText("CARDS LEFT: " + counter);
    if(counter == 0){
      counting.setText("YOU WIN!"); 
    }
  }
  
  public Main() {

    JFrame mainFrame = new JFrame("Memory");
    JPanel mainPanel = new JPanel();
    
    JFrame instFrame = new JFrame("Instructions");
    JPanel instPanel = new JPanel();

    
    //Instructions Window
    instPanel.setLayout(new BorderLayout());
    JLabel header = new JLabel("Instructions:");
    instPanel.add(header, BorderLayout.NORTH);
      
    
    JLabel body = new JLabel("Match all pairs of cards to win. Good Luck!");
    instPanel.add(body, BorderLayout.WEST);

    //Setting up the "ok" button in first window
    JButton button = new JButton("OK");
    button.addActionListener(e -> {
      instFrame.setVisible(false);
      });
    instPanel.add(button, BorderLayout.SOUTH);

    
    //Main Window 
    mainPanel.setLayout(new GridLayout(2,4));
    
    mainPanel.add(counting);
    
    JButton b1 = new JButton(resize(back));
    b1.addActionListener(e1 -> {
      storeButtons(b1);
      storeNums(1);
      changeImage(b1, one);
    });
    mainPanel.add(b1);

    JButton b2 = new JButton(resize(back));
    b2.addActionListener(e2 -> {
      storeButtons(b2);
      storeNums(4);
      changeImage(b2, two);
    });
    mainPanel.add(b2);
    
    JButton b3 = new JButton(resize(back));
    b3.addActionListener(e3 -> {
      storeButtons(b3);
      storeNums(2);
      changeImage(b3, three);
    });
    mainPanel.add(b3);
    
    JButton b4 = new JButton(resize(back));
    b4.addActionListener(e4 -> {
      storeButtons(b4);
      storeNums(4);
      changeImage(b4, two);
    });
    mainPanel.add(b4);

    JButton b5 = new JButton(resize(back));
    b5.addActionListener(e5 -> {
      storeButtons(b5);
      storeNums(3);
      changeImage(b5, four);
    });
    mainPanel.add(b5);

    JButton b6 = new JButton(resize(back));
    b6.addActionListener(e6 -> {
      storeButtons(b6);
      storeNums(3);
      changeImage(b6, four);
    });
    mainPanel.add(b6);

    JButton b7 = new JButton(resize(back));
    b7.addActionListener(e7 -> {
      storeButtons(b7);
      storeNums(1);
      changeImage(b7, one);
    });
    mainPanel.add(b7);

    JButton b8 = new JButton(resize(back));
    b8.addActionListener(e8 -> {
      storeButtons(b8);
      storeNums(2);
      changeImage(b8, three);
    });
    mainPanel.add(b8);

    //"Check" button at bottom
    JButton checkB = new JButton("Check");
    checkB.addActionListener(e9 -> {
      check();
      numSize = true;
      buttonSize = true;
    });
    mainPanel.add(checkB);

    mainFrame.getContentPane().add(mainPanel);
    mainFrame.setSize(500, 550);
    mainFrame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
    mainFrame.setVisible(true);
    instFrame.setAlwaysOnTop(true);
    instFrame.getContentPane().add(instPanel);
    instFrame.setSize(350, 300);
    instFrame.setVisible(true);
  }
       
  public static void main(String[] args) throws Exception {
    new Main();
  }
}
