//Hayden Troxell
import java.util.*;

//Main Method
public class Main {
  public static void main(String[] args) {
        Scanner ab = new Scanner(System.in);
    ArrayList<Character>characters = new ArrayList<Character>();
    int userInput = 0;
    
while(userInput != 9){
    System.out.println("1. Create a character");
    System.out.println("2. Character adds an item");
    System.out.println("3. Character drops an item");
    System.out.println("4. Character sells an item to a vendor");
    System.out.println("5. Character sells an item to another character");
    System.out.println("6. List characters");
    System.out.println("7. List a character's inventory by value");
    System.out.println("8. List all characters' inventories by value");
    System.out.println("9. Quit");
    System.out.print("What would you like to do? ");
    
    userInput = ab.nextInt();
    
if(userInput == 1){
  boolean dup = false;
    System.out.print("What is the Character's name? ");
      String name = ab.next();
  //checks to see if name is already in use
  for(int i=0; i < characters.size(); i++ ){
    if(name == characters.get(i).getName()){
      System.out.println("Error: a character with that name already exists");
      dup = true;
    }
  }
   if(dup){
     continue;
   }else{
     System.out.print("How many credits does the character have? ");
      int credits = ab.nextInt();
     System.out.println(name + " added");
     characters.add(new Character(name, credits));
   }
    
  }else if(userInput == 2){
    boolean exists = false;
    System.out.print("Which character is adding the item? ");
    String name = ab.next();
  //checks to see if character name exists
    for(int i=0; i < characters.size(); i++ ){
      if(name.equals(characters.get(i).getName())){
        System.out.print("What is the name of the item? ");
        String itemName = ab.next();
        System.out.print("What is the item's value? ");
        int itemValue = ab.nextInt();
        characters.get(i).addItem(itemName, itemValue);
        System.out.println(name + " has acquired " + itemName);
        exists = true;
      }
    }
  if(exists){
    continue;
  }else{
    System.out.println("Error: no character with that name exists.");
      
  }
}else if(userInput == 3){
  boolean charExists = false;
  System.out.print("Which character is dropping the item? ");
  String name = ab.next();
  //checks to see if character exists
  for(int i=0; i < characters.size(); i++ ){
    if(name.equals(characters.get(i).getName())){
      System.out.print("What item is the character dropping? ");
      String itemName = ab.next();
      //checks to see if item is able to be dropped
      boolean itemExists = characters.get(i).dropItem(itemName);
      if(itemExists){
        System.out.println(name + " has dropped " + itemName);
        break;
      }else{
        System.out.println(name + " could not drop " + itemName);
      }
        
    }
 }
}else if(userInput == 4){
  System.out.print("Which character is selling the item? ");
  String name = ab.next();
  //checks to see if character exists 
  for(int i=0; i < characters.size(); i++ ){
    if(name.equals(characters.get(i).getName())){
      System.out.print("What item is the character selling? ");
      String itemName = ab.next();
      //checks to see if item exists
     boolean itemExists = characters.get(i).sellItemToVendor(itemName);
      if(itemExists){
      System.out.println(name + " sold " + itemName + " to vendor.");
        break;
      }else{
        System.out.println(name + " does not have " + itemName);
      }
    }
}
}else if(userInput == 5){
  boolean itemExists = false;
  String itemName = "";
   System.out.print("Which character is selling the item? ");
  String name = ab.next();
  //checks to see if item exists
  for(int i=0; i < characters.size(); i++ ){
    if(name.equals(characters.get(i).getName())){
      System.out.print("Which character is buying the item? ");
     String buyer = ab.next();
      //checks to see if buyer name is a character name 
      for(int j=0; j < characters.size(); j++ ){
        if(buyer.equals(characters.get(j).getName())){
          System.out.print("What is the name of the item? ");
          itemName = ab.next();
          itemExists = characters.get(i).sellItemToCharacter(itemName, characters.get(j));
          System.out.println(name + " has sold " + itemName + " to " + buyer);
        }
        if(itemExists){
          break;
        }else{
          System.out.println(name + " could not sell " + itemName + " to " + buyer);
        }
      }  
    }
  }
}
if(userInput == 6){
  Collections.sort(characters);
  for(int i=0; i < characters.size(); i++ ){
    System.out.println(characters.get(i).toString());
  }
}else if(userInput == 7){
  System.out.print("Which character's inventory list would you like to see? ");
 String name = ab.next();
  //checks to see if character name exists
    for(int i=0; i < characters.size(); i++ ){
    if(name.equals(characters.get(i).getName())){
      Collections.sort(characters.get(i).getInventory());
      for(int j = 0; j < characters.get(i).getInventory().size(); j++){
      System.out.println(characters.get(i).getInventory().get(j).toString());
    }
    }
  }
}else if(userInput == 8){
  Collections.sort(characters);
  for(int i=0; i < characters.size(); i++ ){
    System.out.println(characters.get(i).toString());
    Collections.sort(characters.get(i).getInventory());
    for(int j = 0; j < characters.get(i).getInventory().size(); j++){     System.out.println(characters.get(i).getInventory().get(j).toString());
    }
  } 
}else if(userInput == 9){
  System.out.print("Quitting...");
  break;
}
  }
}
}
