import java.util.*;

//Character class
public class Character implements Comparable<Character>{
   private String name;
   private int credits;
   private ArrayList<Item> inventory = new ArrayList<Item>();
  //constructor
  public Character(String name, int credits){
    this.name = name;
    this.credits = credits;
  }
  //Getter
  public String getName(){
    return name;
  }
  //Getter 
  public ArrayList<Item> getInventory(){
    return inventory;
  }
  //Method used to add item and its value
  public void addItem(String itemName, int itemValue){
  inventory.add(new Item(itemName, itemValue));
}
  //Method used for dropping an item
  public boolean dropItem(String itemName){
  for(int i = 0; i < inventory.size(); i++){
    if(itemName.equals(inventory.get(i).getitemName())){
      inventory.remove(i);
      return true;
    }
  }
    return false;
}
  //Method for sellingItem to vendor
  public boolean sellItemToVendor(String itemName){
    for(int i = 0; i < inventory.size(); i++){
    if(itemName.equals(inventory.get(i).getitemName())){
      this.credits += inventory.get(i).getValue();
      inventory.remove(i);
      return true;
    }
  }
    return false;
}
 

  //Method for selling item to characters
  public boolean sellItemToCharacter(String itemName, Character buyer){
    for(int i = 0; i < inventory.size(); i++){
      if(itemName == inventory.get(i).getitemName() && buyer.credits >= inventory.get(i).getValue() ){
        this.credits += inventory.get(i).getValue();
        buyer.addItem(inventory.get(i).getitemName(), inventory.get(i).getValue());
        buyer.credits -= inventory.get(i).getValue();
        this.inventory.remove(i);
        return true;
      }
    }
    return false;
  }
  //Method used to return format of character name as "name(credits)"
  public String toString(){
    return name + "(" + credits + ")";
  }
  public int compareTo(Character other){
  return this.name.compareTo(other.name);
}
}