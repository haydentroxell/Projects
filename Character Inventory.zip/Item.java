import java.util.*;
public class Item implements Comparable<Item> {
private String itemName;
private int value;
  //constructor
  public Item(String itemName, int value){
    this.itemName = itemName;
    this.value = value;
  }
  //Getter for item name
  public String getitemName(){
    return itemName;
  }
  //Getter for value
  public int getValue(){
    return value;
  }
  //Setter for item name
  public void setitemName(String name){
    this.itemName = name;
  }
 //Setter for value
 public void setvalue(int coin){
    this.value = coin;
  }
  //Method used to have format be "item name(value)"
  public String toString(){
    return itemName + "(" + value + ")";
    
  }
public int compareTo(Item other){
  if(this.value > other.value){
  return -1;
  }else if(other.value > this.value){
  return 1;
  }else{
  return 0;
  }
}

}